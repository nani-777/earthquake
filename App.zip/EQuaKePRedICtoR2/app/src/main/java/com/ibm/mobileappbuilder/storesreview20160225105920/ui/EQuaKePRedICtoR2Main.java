package com.ibm.mobileappbuilder.storesreview20160225105920.ui;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

import ibmmobileappbuilder.ui.DrawerActivity;

import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;

public class EQuaKePRedICtoR2Main extends DrawerActivity {

    private final SparseArray<Class<? extends Fragment>> sectionFragments = new SparseArray<>();
    {
                sectionFragments.append(R.id.entry0, EarthQuakEProneFragment.class);
            sectionFragments.append(R.id.entry1, ReviewsFragment.class);
            sectionFragments.append(R.id.entry2, RankingFragment.class);
            sectionFragments.append(R.id.entry3, LogoutFragment.class);
    }

    @Override
    public SparseArray<Class<? extends Fragment>> getSectionFragmentClasses() {
      return sectionFragments;
    }

}

