
package com.ibm.mobileappbuilder.storesreview20160225105920.ui;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDSService;
import com.ibm.mobileappbuilder.storesreview20160225105920.presenters.ReviewsFormPresenter;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.ds.restds.GeoPoint;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.GeoPicker;
import ibmmobileappbuilder.views.ImagePicker;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import java.io.IOException;
import java.io.File;

import static android.net.Uri.fromFile;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDS;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

public class EquakeDSItemFormFragment extends FormFragment<EquakeDSItem> {

    private CrudDatasource<EquakeDSItem> datasource;

    public static EquakeDSItemFormFragment newInstance(Bundle args){
        EquakeDSItemFormFragment fr = new EquakeDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public EquakeDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new ReviewsFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

        addBehavior(pageViewBehavior("Reviews"));
    }

    @Override
    protected EquakeDSItem newItem() {
        return new EquakeDSItem();
    }

    private EquakeDSService getRestService(){
        return EquakeDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.reviews_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final EquakeDSItem item, View view) {
        
        bindLocation(R.id.equakeds_location, item.lOCATION,
            new GeoPicker.PointChangedListener() {
                @Override
                public void onPointChanged(GeoPoint point) {
                    item.lOCATION = point;
                }
            }
        );
        
        
        bindDouble(R.id.equakeds_magnitude, item.mAGNITUDE, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.mAGNITUDE = StringUtils.parseDouble(s.toString());
            }
        });
        
        
        bindImage(R.id.equakeds_picture,
            item.picture != null ?
                getRestService().getImageUrl(item.picture) : null,
            0,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.picture = null;
                    item.pictureUri = null;
                    ((ImagePicker) getView().findViewById(R.id.equakeds_picture)).clear();
                }
            }
        );
        
        
        bindString(R.id.equakeds_city, item.cITY, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.cITY = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<EquakeDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = EquakeDS.getInstance(new SearchOptions());
        return datasource;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK) {
            ImagePicker picker = null;
            Uri imageUri = null;
            EquakeDSItem item = getItem();

            if((requestCode & ImagePicker.GALLERY_REQUEST_CODE) == ImagePicker.GALLERY_REQUEST_CODE) {
              imageUri = data.getData();
              switch (requestCode - ImagePicker.GALLERY_REQUEST_CODE) {
                        
                        case 0:   // picture field
                            item.pictureUri = imageUri;
                            item.picture = "cid:picture";
                            picker = (ImagePicker) getView().findViewById(R.id.equakeds_picture);
                            break;
                        
                default:
                  return;
              }

              picker.setImageUri(imageUri);
            } else if((requestCode & ImagePicker.CAPTURE_REQUEST_CODE) == ImagePicker.CAPTURE_REQUEST_CODE) {
				      switch (requestCode - ImagePicker.CAPTURE_REQUEST_CODE) {
                        
                        case 0:   // picture field
                            picker = (ImagePicker) getView().findViewById(R.id.equakeds_picture);
                            imageUri = fromFile(picker.getImageFile());
                        		item.pictureUri = imageUri;
                            item.picture = "cid:picture";
                            break;
                        
                default:
                  return;
              }
              picker.setImageUri(imageUri);
            }
        }
    }
}

