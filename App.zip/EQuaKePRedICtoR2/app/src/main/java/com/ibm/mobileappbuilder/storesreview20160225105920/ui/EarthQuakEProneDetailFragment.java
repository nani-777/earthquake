
package com.ibm.mobileappbuilder.storesreview20160225105920.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDS;

public class EarthQuakEProneDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<EquakeDSItem>  {

    private Datasource<EquakeDSItem> datasource;
    public static EarthQuakEProneDetailFragment newInstance(Bundle args){
        EarthQuakEProneDetailFragment fr = new EarthQuakEProneDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public EarthQuakEProneDetailFragment(){
        super();
    }

    @Override
    public Datasource<EquakeDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = EquakeDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.earthquakepronedetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final EquakeDSItem item, View view) {
        if (item.lOCATION != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.lOCATION.toString());
            
        }
        if (item.mAGNITUDE != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(StringUtils.doubleToString(item.mAGNITUDE, true));
            
        }
        
        ImageView view2 = (ImageView) view.findViewById(R.id.view2);
        URL view2Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.picture);
        if(view2Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view2.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view2Media.toExternalForm())
                                   .withTargetView(view2)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view2.setImageDrawable(null);
        }
        if (item.cITY != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText(item.cITY);
            
        }
    }

    @Override
    protected void onShow(EquakeDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }
}

