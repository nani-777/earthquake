package com.ibm.mobileappbuilder.storesreview20160225105920.ui;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.TextView;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.behaviors.AnalyticsSearchBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.restds.GeoPoint;
import ibmmobileappbuilder.ui.Filterable;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EquakeDS;
import ibmmobileappbuilder.behaviors.SearchBehavior;
import ibmmobileappbuilder.behaviors.AnalyticsSearchBehavior;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

/**
 * "EarthQuakEProneFragment" listing
 */
public class EarthQuakEProneFragment extends ibmmobileappbuilder.maps.ui.MapFragment<EquakeDSItem> {
    private SearchBehavior searchBehavior;
    private Datasource<EquakeDSItem> datasource;
    private SearchOptions searchOptions;

    public static EarthQuakEProneFragment newInstance(Bundle args){
        EarthQuakEProneFragment fr = new EarthQuakEProneFragment();
        fr.setArguments(args);

        return fr;
    }

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

addBehavior(pageViewBehavior("EarthQuakEProne"));
        // If searchable behavior
        setHasOptionsMenu(true);
        searchBehavior = new AnalyticsSearchBehavior(this, "EquakeDS");
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        searchBehavior.onCreateOptionsMenu(menu, inflater);
    }
	  @Override
    protected Datasource<EquakeDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
        searchOptions = SearchOptions.Builder.searchOptions().build();
       datasource = EquakeDS.getInstance(searchOptions);
        return datasource;
    }

    @Override
    protected int getMapType() {
        return GoogleMap.MAP_TYPE_TERRAIN;
    }

    @Override
    protected String getLocationField() {
        return "lOCATION";
    }

    @Override
    protected Marker createAndBindMarker(GoogleMap map, EquakeDSItem item) {
        return map.addMarker(new MarkerOptions()
                        .position(
                                new LatLng(getLocationForItem(item).coordinates[1],
                                        getLocationForItem(item).coordinates[0]))
                        // Binding
                        .title(StringUtils.doubleToString(item.mAGNITUDE, true))
                        .snippet(item.lOCATION.toString())
        );
    }


    protected GeoPoint getLocationForItem(EquakeDSItem item) {
        return item.lOCATION;
    }

    @Override
    public void navigateToDetail(EquakeDSItem item) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(Constants.CONTENT, item);
        new StartActivityAction(EarthQuakEProneDetailActivity.class, bundle).execute(getActivity());
    }
}

