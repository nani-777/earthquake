

package com.ibm.mobileappbuilder.storesreview20160225105920.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import ibmmobileappbuilder.analytics.injector.NetworkLoggerInjector;
import ibmmobileappbuilder.analytics.injector.RetrofitResponseNetworkLoggerInjector;

/**
 * "EquakeDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class EquakeDS extends AppNowDatasource<EquakeDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private EquakeDSService service;

    public static EquakeDS getInstance(SearchOptions searchOptions){
        return new EquakeDS(searchOptions);
    }

    private EquakeDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = EquakeDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<EquakeDSItem> listener) {
        if ("0".equals(id)) {
            NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS", "GET");
            getItems(new Listener<List<EquakeDSItem>>() {
                @Override
                public void onSuccess(List<EquakeDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new EquakeDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
          NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS"+id, "GET");
            service.getServiceProxy().getEquakeDSItemById(id, new Callback<EquakeDSItem>() {
                @Override
                public void success(EquakeDSItem result, Response response) {
                    RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                    listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                    RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                    listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<EquakeDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<EquakeDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS?skip="+skip+"&limit="+limit+"&conditions="+conditions+"&sort="+sort+"&select=null&populate=null", "GET");
        service.getServiceProxy().queryEquakeDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<EquakeDSItem>>() {
            @Override
            public void success(List<EquakeDSItem> result, Response response) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"cITY"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS?distinct="+searchStr+"&conditions="+conditions, "GET");
        service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                 RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                 result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                 RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                 listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(EquakeDSItem item, Listener<EquakeDSItem> listener) {
      NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS", "POST");
              
        if(item.pictureUri != null){
            service.getServiceProxy().createEquakeDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createEquakeDSItem(item, callbackFor(listener));
        
    }

    private Callback<EquakeDSItem> callbackFor(final Listener<EquakeDSItem> listener) {
      return new Callback<EquakeDSItem>() {
          @Override
          public void success(EquakeDSItem item, Response response) {
              RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
              listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
              RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
              listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(EquakeDSItem item, Listener<EquakeDSItem> listener) {
      NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS", "PUT");
              
        if(item.pictureUri != null){
            service.getServiceProxy().updateEquakeDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateEquakeDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(EquakeDSItem item, final Listener<EquakeDSItem> listener) {
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS", "DELETE");
        service.getServiceProxy().deleteEquakeDSItemById(item.getIdentifiableId(), new Callback<EquakeDSItem>() {
            @Override
            public void success(EquakeDSItem result, Response response) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<EquakeDSItem> items, final Listener<EquakeDSItem> listener) {
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4/r/equakeDS", "POST");
        service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<EquakeDSItem>>() {
            @Override
            public void success(List<EquakeDSItem> item, Response response) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<EquakeDSItem> items){
        List<String> ids = new ArrayList<>();
        for(EquakeDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

