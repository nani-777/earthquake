
package com.ibm.mobileappbuilder.storesreview20160225105920.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "EquakeDSService" REST Service implementation
 */
public class EquakeDSService extends RestService<EquakeDSServiceRest>{

    public static EquakeDSService getInstance(){
          return new EquakeDSService();
    }

    private EquakeDSService() {
        super(EquakeDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "DTbJRnKe";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57efa1f6493d14030084a7b4",
                path,
                "apikey=DTbJRnKe");
    }

}

